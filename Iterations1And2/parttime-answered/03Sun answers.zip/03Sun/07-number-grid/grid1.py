
for i in range(0,100):
    print("{:<3}".format(i), end="")
    if i % 10 == 9:
        print()