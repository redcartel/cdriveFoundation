
for tens in range(0,60,20):
    for ones in range(0,20):
        print("{:<3}".format(tens + ones), end="")
    print()