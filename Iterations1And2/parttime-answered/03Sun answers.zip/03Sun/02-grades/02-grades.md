## Grades

* Prompt the user to input a number between 0.0 and 1.0 (inclusive)

* Store the letter equivalent of their grade in a variable called gradeletter

* If the number is less than 0.0 or greater than 1.0, give an error and exit the program with quit()

* If the number is greater than or equal to 0.9 the grade is an "A"

* If the number is greater than or equal to 0.8 and less than 0.9 the grade is a "B"

* If the number is greater than or equal to 0.7 and less than 0.8 the grade is a "C"

* If the number is greater than or equal to 0.6 and less than 0.7 the grade is a "D"

* If the number is less than 0.6 the grade is an "F"

* Print "Your earned a <gradeletter>" if gradeletter is an A or an F, say "You earned an <gradeletter>"