## Day 2  Exercise 5 - for and while

* Write a program that inputs an integer from the user and then prints the even numbers from 0 to that integer (including that integer, if it is even). Use a for loop.

* Now do the same but with a while loop.