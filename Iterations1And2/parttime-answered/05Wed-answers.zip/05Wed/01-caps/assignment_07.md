## Day 5 Exercise 1 - Caps

* Write a program that prompts for a file name, then opens that file and reads through the file, and print the contents of the file in upper case. Use the file words.txt

* Now write the program to output the caps version of the file into a new file.