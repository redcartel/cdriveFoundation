## Day 5 Exercise 4 json & dictionary

* In this folder is a json file for a snapshot of Tesla's market information.

* Open the file and load it into a dictionary

* Print a list with every key and its value (use a loop)

* Create a new dictionary with just the Name, Symbol, LastPrice and Volume keys.

* Write that dictionary to a json file with the name 'tsla_summary.json'