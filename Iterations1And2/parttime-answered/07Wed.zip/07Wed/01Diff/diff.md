## diff

Write a program to compare two text files. For each line where the files differ, print the line number and the two differing lines.

Look up:
how to open more than one file in a with statement
enumerate and zip

It's possible to solve this with four lines of code