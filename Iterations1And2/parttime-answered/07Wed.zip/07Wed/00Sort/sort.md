## Sorted insert

# Write a program that manually keeps a sorted list of 5 integers.

# The list starts as 0, 0, 0, 0, 0

# A while loop prompts the user to input new positive integers

# The list is sorted from least to greatest and displayed after each input.

```
0, 0, 0, 0, 0

add a number: 5

0, 0, 0, 0, 5

add a number: 2

0, 0, 0, 2, 5

add a number: 4

0, 0, 2, 4, 5

add a number: 6

0, 2, 4, 5, 6

add a number: 1

1, 2, 4, 5, 6

add a number: 2

2, 2, 4, 5, 6

add a number: 1

2, 2, 4, 5, 6

add a number: done
```

do not use the sort or sorted functions