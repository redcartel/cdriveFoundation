three = 3
pigs = "little pigs"

print("The {} {}".format(three, pigs))

x = 6.7

print("{:0.4}".format(x))

sam = "Sam"
jo = "Josephine"

print("The joint account for {:<13} and {:<13} has $1000.00".format(sam, jo))
print("The joint account for {:>13} and {:>13} has $1000.00".format(sam, jo))

print(80 * "#")