## Input Loop

* Ask a user to input names until they input the phrase 'done'

* After inputting the names, print the number of names that are exactly two words (a first name and a last name) whose first name is at least 4 characters

```
Give me a name: Carter Adams
Give me a name: Jon Arbuckle
Give me a name: Kenso Trabing
Give me a name: Lee Harvey Oswald
Give me a name: done
2 names pass the test.
```
