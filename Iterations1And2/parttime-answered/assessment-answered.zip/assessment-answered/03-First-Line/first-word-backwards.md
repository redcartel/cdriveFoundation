## Final Assessment - First Word Backwards

* From the user input a filename

* Open that file and read the contents.

* Print a list of the first word of each line in reverse order. Number the words starting with 1 with the first word printed numbered 1.

* Output for the provided file should be:
```
1 :  To
2 :  Pity
3 :  And,
4 :  Within
5 :  And
6 :  Thou
7 :  Thyself
8 :  Making
9 :  Feed’st
10 :  But
11 :  His
12 :  But
13 :  That
14 :  From
```