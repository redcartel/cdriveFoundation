## Final Assessment - Title Case

* Take a sentence from user input

* Take a second list of words from user input

* Capitalize the first letter of each word and output the new string that does not appear
in the second list of words.

```
Input a string: now is the time for all good men to come to the aid of their country

Word to not capitalize: is the to of

Now is the Time For All Good Men to Come to the Aid of Their Country
```

* hint: the ```title()``` method of strings.