
def print_list(input_list):
    ## Print each element of the list on its own line
    ## preceded by 'line <n>: ' where n is a numbering from 0
    ## to the final index of the list
    pass


def squares_to(maximum):
    ## for each value between 0 and maximum (from 0 to maximum-1), square that value,
    ## and return a list of those squares in ascending order.
    ##
    ## so if maximum is 5, return [0, 1, 4, 9, 16]
    pass

if __name__ == "__main__":
    x = 12
    print_list(squares_to(x))