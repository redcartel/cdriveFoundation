## Final Assessment - Functions

* Use the starter code provided:

* Don't change the code in ```if __name__ == "__main__":```

* Complete the two functions as described

* The output should be:

```
line 0 :  0
line 1 :  1
line 2 :  4
line 3 :  9
line 4 :  16
line 5 :  25
line 6 :  36
line 7 :  49
line 8 :  64
line 9 :  81
line 10 :  100
line 11 :  121
```