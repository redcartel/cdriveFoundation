# Hackerrank and Reading

## Think Python

The excellent book, Think Python is available for free online. It organizes its material differently than we do our curriculum but seeing ideas more than one time is a good way to really learn them.

[https://greenteapress.com/wp/think-python/]

* Read chapters one and two of 'Think Python'

* Turn in the answers to the exercises with your coding work.
